package com.mybank.hongik;

public class HongikBank {

}
