package com.mybank.hongik;

public class HongikAccount {

}
