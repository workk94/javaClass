package com.mybank.user;

import java.io.Serializable;

public class User implements Serializable{
	
	//field
	private String userName; // 이름 
	private String ssn; // 주민번호
	private String id; // 아이디
	private String password; // 패스워드
	private String[] myAccount = new String[3]; //계좌배열

}
