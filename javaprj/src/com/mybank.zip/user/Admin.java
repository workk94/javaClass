package com.mybank.user;

public class Admin {
	
	//field
	private String id;
	private String password;
}
