package com.mybank.bank;

public interface Transaction {
	
	//입금 
	public boolean deposit(String accountNumber, double amount);
	
	//출금 
	public boolean withdraw(String accountNumber, double amount);
	
	//송금 
	public boolean transfer(String fromAccount, String toAccount, double amount);
	
	// 거래처리
	
	
	// 거래내역 저장 
}
