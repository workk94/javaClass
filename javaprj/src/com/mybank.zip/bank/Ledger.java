package com.mybank.bank;

import com.mybank.util.DataStorage;

public abstract class Ledger {
	
	private long totalBalance;
	
	public Ledger() {
		
	}
	

	public long getTotalBalance() {
		return totalBalance;
	}	
}
