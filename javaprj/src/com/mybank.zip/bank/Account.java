package com.mybank.bank;

import java.io.Serializable;

public abstract class Account implements Serializable{
	private String accountNumber; // 계좌번호
	private double accountBalance; // 계좌금액
	private String accountPassword;
	private long AccountBalance;
	private String fromAccount;
	private String toAccount;
}
