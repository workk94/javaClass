package com.mybank.bank;

import com.mybank.user.User;
import java.util.ArrayList;

public abstract class Bank implements Transaction{
	
	//field
	private String bankName;
	private ArrayList<Account> accounts;
	private ArrayList<User> users;
	
	//constructor
	public Bank(String bankName){
		this.bankName = bankName;
	}
	
	public String getName() {
		return bankName;
	}

	//method
	public abstract void addAccount(Account account);
	public abstract Account getAccount(String accountNumber);
	
}
