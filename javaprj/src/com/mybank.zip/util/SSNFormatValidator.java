package com.mybank.util;

public class SSNFormatValidator {
	public boolean validator() {
		String patternType = "\\d{6}\\-[1-4]\\d{6}";
		return false;
		
	}
}
