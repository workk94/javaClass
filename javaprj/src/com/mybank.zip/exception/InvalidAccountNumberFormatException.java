package com.mybank.exception;


//계좌번호 
//https://namu.wiki/w/%EA%B3%84%EC%A2%8C%EB%B2%88%ED%98%B8
//11자리 ~ 14자리 
//
public class InvalidAccountNumberFormatException extends RuntimeException{

}
