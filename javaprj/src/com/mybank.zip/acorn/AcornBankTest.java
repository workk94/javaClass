package com.mybank.acorn;

public class AcornBankTest {
	public static void main(String[] args) {
		
		AcornBankApp app = new AcornBankApp();
		
		app.run();
		
	}
}
