package com.mybank.acorn;

import com.mybank.bank.Account;

public class AcornAccount extends Account{

}
