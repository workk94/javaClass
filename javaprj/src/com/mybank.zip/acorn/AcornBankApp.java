package com.mybank.acorn;

import java.util.Scanner;

public class AcornBankApp {
	private AcornBank b = new AcornBank("본점");
	private Scanner sc = new Scanner(System.in);

	public void run() {

		while (true) {
			System.out.println(b.getName() + "에 오신것을 환영합니다");
			System.out.println("메뉴선택 [1]관리자용 [2]고객용 [3]종료: ");

			String select = sc.nextLine();

			switch (select) {
			case "1":
				System.out.println("관리자용");
				adminMenu();
				break;
			case "2":
				System.out.println("고객용");
				clientMenu();
				break;
			case "3" : 
				System.out.println("종료합니다 안녕히가세요");
				
				System.exit(0);
			default:
				System.out.println("잘못된 입력입니다");
			}
		}
	}

	public void clientMenu() {
		while (true) {
			System.out.println("메뉴를 선택해주세요 [1] 계좌개설, [2]입금, [3]출금, [4]송금, [4]전단계");
			String select = sc.nextLine();
			switch (select) {
			case "1":
				System.out.println("계좌개설");
				break;
			case "2":
				boolean result = login();
				if(result) {
					loginSuccessMenu();
				} 
				
				System.out.println("로그인");
				break;
			case "3":
				System.out.println("종료");
				System.exit(0);
			case "4":
				System.out.println("전단계로 이동");
				return;
			default:
				System.out.println("잘못된 입력입니다");
			}
		}
	}
	
	public boolean login() {
		String accountNumber = null;
		boolean result = false;
		try {
			System.out.print("계좌번호 입력 : ");
			accountNumber = sc.nextLine();
			System.out.print("계좌비밀번호 입력 : ");
			sc.nextLine();
			String password = sc.nextLine();
			b.getAccount(null);
			
		} catch(Exception e) {
			
		}
		
		//null인 경우 
		if(b.getAccount(accountNumber) == null) {
			System.out.println("비밀번호가 일치하지 않습니다");
			return true;
		}
		
		return true;
		
	}
	
	
	public void loginSuccessMenu() {
		while (true) {
			System.out.println("메뉴를 선택해주세요 [1]입금, [3]출금, [4]송금, [4]전단계");
			String select = sc.nextLine();
			switch (select) {
			case "1":
				boolean result = login();
				if(result) {
					
				}
				
				System.out.println("로그인");
				break;
			case "3":
				System.out.println("종료");
				System.exit(0);
			case "4":
				System.out.println("전단계로 이동");
				return;
			default:
				System.out.println("잘못된 입력입니다");
			}
		}
	}

	public void adminMenu() {
		while (true) {
			System.out.println("메뉴를 선택해주세요 [1]전체계좌조회, [2]직원정보조회, [3]종료, [4]전단계");
			String select = sc.nextLine();
			switch (select) {
			case "1":
				System.out.println("전체계좌조회");
				break;
			case "2":
				System.out.println("로그인");
				break;
			case "3":
				System.out.println("종료");
				System.exit(0);
			case "4":
				System.out.println("전단계로 이동");
				return;
			default:
				System.out.println("잘못된 입력입니다");
			}
		}
	}

}
