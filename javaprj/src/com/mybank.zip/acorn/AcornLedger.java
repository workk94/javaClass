package com.mybank.acorn;

import com.mybank.bank.Ledger;

public class AcornLedger extends Ledger{
	
}
