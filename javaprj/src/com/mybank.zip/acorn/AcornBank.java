package com.mybank.acorn;

import java.util.Scanner;
import com.mybank.bank.Account;
import com.mybank.bank.Bank;

public class AcornBank extends Bank {
	
	private Scanner sc = new Scanner(System.in);

	public AcornBank(String bankName) {
		super("에이콘은행" + " " + bankName);		 
	}
	
	
	
	@Override
	public void addAccount(Account account) {
		System.out.print("주민번호를 입력해주세요 : ");
		
		
	}

	@Override
	public Account getAccount(String accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deposit(String accountNumber, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean withdraw(String accountNumber, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean transfer(String fromAccount, String toAccount, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

}
